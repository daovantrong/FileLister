# FileLister Test Readme

This is a test readme file to verify the **Readme Rendering** feature.

- [x] Docker Support
- [x] Default Index
- [x] File Hashing
- [x] Readme Rendering

## Code Block Example
```php
<?php
echo "Hello World";
?>
```
